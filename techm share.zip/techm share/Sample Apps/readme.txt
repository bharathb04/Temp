INSTRUCTIONS FOR EXECUTION

1. Launch the bundled webserver application at MFCxView-webserver_FORSDK (see README at MFCxView-webserver_FORSDK folder for details)

2. Note the URL

3. Update line 5 of the db2 test1.html file with the URL of the above webserver, but replace index.html with mainspace-ia.js
   For example, for Resource URL           http://127.0.0.1:8888/classpath/5/mfc/resource/index1.html
   Update line 5 to below
       <script type="text/javascript" src="http://127.0.0.1:8888/classpath/5/mfc/resource/mainspace-ia.js"></script>

4. Update db2 test1.html   db2ssid and sqltest variables as per previous instructions.

5. Copy db2 test1.html file to a location on your pc and add to MainSpace as per previous instructions.

