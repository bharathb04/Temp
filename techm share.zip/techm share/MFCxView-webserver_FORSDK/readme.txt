INSTRUCTIONS FOR EXECUTION

1. Launch the application by double clicking   MFCxView-webserver.bat

2. To change the port, update the Web Server Port field and click the Restart button.

3. To TEST the application, copy the Resource URL to a browser on your PC, and confirm a web page is displayed showing the following information:
   On Prem IA SDK Version = 2.0012
   On Prem MfC Commons Version = 1.0003
   On Prem Mfc Utils Version = 1.0001 

4. To USE the application, note the Resource URL and see readme.txt at the Sample Apps folder.

